

function Form_Validation_For_Raising()
{
   

    //start Tensile Properties Warp
    // if(isNaN(document.getElementById("tensile_warp_value1").value))
    // {
    //     number_alert("tensile_warp_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("tensile_warp_value2").value))
    // {
    //     number_alert("tensile_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("tensile_warp_cond1").value == 1 && (parseFloat(document.getElementById("tensile_warp_value2").value)) <= (parseFloat(document.getElementById("tensile_warp_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "tensile_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("tensile_warp_cond1").value == 2 && (parseFloat(document.getElementById("tensile_warp_value2").value)) < (parseFloat(document.getElementById("tensile_warp_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "tensile_warp_value2");
    //     return false;
    // }


    // //start Tensile Properties weft
    // if(isNaN(document.getElementById("tensile_weft_value1").value))
    // {
    //     number_alert("tensile_weft_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("tensile_weft_value2").value))
    // {
    //     number_alert("tensile_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("tensile_weft_cond1").value == 1 && (parseFloat(document.getElementById("tensile_weft_value2").value)) <= (parseFloat(document.getElementById("tensile_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "tensile_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("tensile_weft_cond1").value == 2 && (parseFloat(document.getElementById("tensile_weft_value2").value)) < (parseFloat(document.getElementById("tensile_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "tensile_weft_value2");
    //     return false;
    // }


    // //start  Tear Force Warp
    // if(isNaN(document.getElementById("tear_force_warp_value1").value))
    // {
    //     number_alert("tear_force_warp_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("tear_force_warp_value2").value))
    // {
    //     number_alert("tear_force_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("tear_force_warp_cond1").value == 1 && (parseFloat(document.getElementById("tear_force_warp_value2").value)) <= (parseFloat(document.getElementById("tear_force_warp_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "tear_force_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("tear_force_warp_cond1").value == 2 && (parseFloat(document.getElementById("tear_force_warp_value2").value)) < (parseFloat(document.getElementById("tear_force_warp_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "tear_force_warp_value2");
    //     return false;
    // }


    // //start Tear Force weft
    // if(isNaN(document.getElementById("tear_force_weft_value1").value))
    // {
    //     number_alert("tear_force_weft_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("tear_force_weft_value2").value))
    // {
    //     number_alert("tear_force_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("tear_force_weft_cond1").value == 1 && (parseFloat(document.getElementById("tear_force_weft_value2").value)) <= (parseFloat(document.getElementById("tear_force_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "tear_force_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("tear_force_weft_cond1").value == 2 && (parseFloat(document.getElementById("tear_force_weft_value2").value)) < (parseFloat(document.getElementById("tear_force_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "tear_force_weft_value2");
    //     return false;
    // }




    
}