

function Form_Validation_For_Finishing()
{
    // if(isNaN(document.getElementById("cf_rubbing_dry_value1").value))
    // {
    //     number_alert("cf_rubbing_dry_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_rubbing_dry_value2").value))
    // {
    //     number_alert("cf_rubbing_dry_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_rubbing_dry_cond1").value == 1 && (parseFloat(document.getElementById("cf_rubbing_dry_value2").value)) <= (parseFloat(document.getElementById("cf_rubbing_dry_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_rubbing_dry_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_rubbing_dry_cond1").value == 2 && (parseFloat(document.getElementById("cf_rubbing_dry_value2").value)) < (parseFloat(document.getElementById("cf_rubbing_dry_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_rubbing_dry_value2");
    //     return false;
    // }


    // //start Color Fastness to Rubbing Wet
    // if(isNaN(document.getElementById("cf_rubbing_wet_value1").value))
    // {
    //     number_alert("cf_rubbing_wet_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_rubbing_wet_value2").value))
    // {
    //     number_alert("cf_rubbing_wet_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_rubbing_wet_cond1").value == 1 && (parseFloat(document.getElementById("cf_rubbing_wet_value2").value)) <= (parseFloat(document.getElementById("cf_rubbing_wet_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_rubbing_wet_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_rubbing_wet_cond1").value == 2 && (parseFloat(document.getElementById("cf_rubbing_wet_value2").value)) < (parseFloat(document.getElementById("cf_rubbing_wet_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_rubbing_wet_value2");
    //     return false;
    // }

    // //start Dimensional Change to Washing & Drying Warp (Befor Iron)
    // if(document.getElementById("wash_dry_warp_before_iron_cond1").value == "")
    // {
    //     missing_alert("wash_dry_warp_before_iron_cond1");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_warp_before_iron_value1").value == "")
    // {
    //     missing_alert("wash_dry_warp_before_iron_value1");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_warp_before_iron_value2").value == "")
    // {
    //     missing_alert("wash_dry_warp_before_iron_value2");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_warp_before_iron_cond2").value == "")
    // {
    //     missing_alert("wash_dry_warp_before_iron_cond2");
    //     return false;
    // }
    // if(isNaN(document.getElementById("wash_dry_warp_before_iron_value1").value))
    // {
    //     number_alert("wash_dry_warp_before_iron_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("wash_dry_warp_before_iron_value2").value))
    // {
    //     number_alert("wash_dry_warp_before_iron_value2");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_warp_before_iron_cond1").value == 1 && (parseFloat(document.getElementById("wash_dry_warp_before_iron_value2").value)) <= (parseFloat(document.getElementById("wash_dry_warp_before_iron_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "wash_dry_warp_before_iron_value2");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_warp_before_iron_cond1").value == 2 && (parseFloat(document.getElementById("wash_dry_warp_before_iron_value2").value)) < (parseFloat(document.getElementById("wash_dry_warp_before_iron_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "wash_dry_warp_before_iron_value2");
    //     return false;
    // }

    // //Dimensional Change to Washing & Drying Weft (Befor Iron)
    // if(document.getElementById("wash_dry_weft_before_iron_cond1").value == "")
    // {
    //     missing_alert("wash_dry_weft_before_iron_cond1");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_weft_before_iron_value1").value == "")
    // {
    //     missing_alert("wash_dry_weft_before_iron_value1");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_weft_before_iron_value2").value == "")
    // {
    //     missing_alert("wash_dry_weft_before_iron_value2");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_weft_before_iron_cond2").value == "")
    // {
    //     missing_alert("wash_dry_weft_before_iron_cond2");
    //     return false;
    // }
    // if(isNaN(document.getElementById("wash_dry_weft_before_iron_value1").value))
    // {
    //     number_alert("wash_dry_weft_before_iron_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("wash_dry_weft_before_iron_value2").value))
    // {
    //     number_alert("wash_dry_weft_before_iron_value2");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_weft_before_iron_cond1").value == 1 && (parseFloat(document.getElementById("wash_dry_weft_before_iron_value2").value)) <= (parseFloat(document.getElementById("wash_dry_weft_before_iron_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "wash_dry_weft_before_iron_value2");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_weft_before_iron_cond1").value == 2 && (parseFloat(document.getElementById("wash_dry_weft_before_iron_value2").value)) < (parseFloat(document.getElementById("wash_dry_weft_before_iron_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "wash_dry_weft_before_iron_value2");
    //     return false;
    // }

    // //start Dimensional Change to Washing & Drying Warp (After Iron)
    // if(document.getElementById("wash_dry_warp_after_iron_cond1").value == "")
    // {
    //     missing_alert("wash_dry_warp_after_iron_cond1");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_warp_after_iron_value1").value == "")
    // {
    //     missing_alert("wash_dry_warp_after_iron_value1");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_warp_after_iron_value2").value == "")
    // {
    //     missing_alert("wash_dry_warp_after_iron_value2");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_warp_after_iron_cond2").value == "")
    // {
    //     missing_alert("wash_dry_warp_after_iron_cond2");
    //     return false;
    // }
    // if(isNaN(document.getElementById("wash_dry_warp_after_iron_value1").value))
    // {
    //     number_alert("wash_dry_warp_after_iron_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("wash_dry_warp_after_iron_value2").value))
    // {
    //     number_alert("wash_dry_warp_after_iron_value2");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_warp_after_iron_cond1").value == 1 && (parseFloat(document.getElementById("wash_dry_warp_after_iron_value2").value)) <= (parseFloat(document.getElementById("wash_dry_warp_after_iron_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "wash_dry_warp_after_iron_value2");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_warp_after_iron_cond1").value == 2 && (parseFloat(document.getElementById("wash_dry_warp_after_iron_value2").value)) < (parseFloat(document.getElementById("wash_dry_warp_after_iron_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "wash_dry_warp_after_iron_value2");
    //     return false;
    // }


    // //start Dimensional Change to Washing & Drying Weft (After Iron)
    // if(document.getElementById("wash_dry_weft_after_iron_cond1").value == "")
    // {
    //     missing_alert("wash_dry_weft_after_iron_cond1");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_weft_after_iron_value1").value == "")
    // {
    //     missing_alert("wash_dry_weft_after_iron_value1");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_weft_after_iron_value2").value == "")
    // {
    //     missing_alert("wash_dry_weft_after_iron_value2");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_weft_after_iron_cond2").value == "")
    // {
    //     missing_alert("wash_dry_weft_after_iron_cond2");
    //     return false;
    // }
    // if(isNaN(document.getElementById("wash_dry_weft_after_iron_value1").value))
    // {
    //     number_alert("wash_dry_weft_after_iron_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("wash_dry_weft_after_iron_value2").value))
    // {
    //     number_alert("wash_dry_weft_after_iron_value2");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_weft_after_iron_cond1").value == 1 && (parseFloat(document.getElementById("wash_dry_weft_after_iron_value2").value)) <= (parseFloat(document.getElementById("wash_dry_weft_after_iron_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "wash_dry_weft_after_iron_value2");
    //     return false;
    // }
    // if(document.getElementById("wash_dry_weft_after_iron_cond1").value == 2 && (parseFloat(document.getElementById("wash_dry_weft_after_iron_value2").value)) < (parseFloat(document.getElementById("wash_dry_weft_after_iron_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "wash_dry_weft_after_iron_value2");
    //     return false;
    // }


    // //start Dimensional Change to Dry Cleaning Warp
    // if(isNaN(document.getElementById("dry_cleaning_warp_value1").value))
    // {
    //     number_alert("dry_cleaning_warp_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("dry_cleaning_warp_value2").value))
    // {
    //     number_alert("dry_cleaning_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("dry_cleaning_warp_cond1").value == 1 && (parseFloat(document.getElementById("dry_cleaning_warp_value2").value)) <= (parseFloat(document.getElementById("dry_cleaning_warp_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "dry_cleaning_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("dry_cleaning_warp_cond1").value == 2 && (parseFloat(document.getElementById("dry_cleaning_warp_value2").value)) < (parseFloat(document.getElementById("dry_cleaning_warp_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "dry_cleaning_warp_value2");
    //     return false;
    // }


    // //start Dimensional Change to Dry Cleaning Weft
    // if(isNaN(document.getElementById("dry_cleaning_weft_value1").value))
    // {
    //     number_alert("dry_cleaning_weft_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("dry_cleaning_weft_value2").value))
    // {
    //     number_alert("dry_cleaning_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("dry_cleaning_weft_cond1").value == 1 && (parseFloat(document.getElementById("dry_cleaning_weft_value2").value)) <= (parseFloat(document.getElementById("dry_cleaning_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "dry_cleaning_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("dry_cleaning_weft_cond1").value == 2 && (parseFloat(document.getElementById("dry_cleaning_weft_value2").value)) < (parseFloat(document.getElementById("dry_cleaning_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "dry_cleaning_weft_value2");
    //     return false;
    // }


    // //start Yarn Count for Warp
    // if(document.getElementById("yarn_count_warp_cond1").value == "")
    // {
    //     missing_alert("yarn_count_warp_cond1");
    //     return false;
    // }
    // if(document.getElementById("yarn_count_warp_value1").value == "")
    // {
    //     missing_alert("yarn_count_warp_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("yarn_count_warp_value1").value))
    // {
    //     number_alert("yarn_count_warp_value1");
    //     return false;
    // }
    // if(document.getElementById("yarn_count_warp_value2").value == "")
    // {
    //     missing_alert("yarn_count_warp_value2");
    //     return false;
    // }
    // if(isNaN(document.getElementById("yarn_count_warp_value2").value))
    // {
    //     number_alert("yarn_count_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("yarn_count_warp_cond1").value == 1 && (parseFloat(document.getElementById("yarn_count_warp_value2").value)) <= (parseFloat(document.getElementById("yarn_count_warp_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "yarn_count_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("yarn_count_warp_cond1").value == 2 && (parseFloat(document.getElementById("yarn_count_warp_value2").value)) < (parseFloat(document.getElementById("yarn_count_warp_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "yarn_count_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("yarn_count_warp_cond2").value == "")
    // {
    //     missing_alert("yarn_count_warp_cond2");
    //     return false;
    // }


    // //start Yarn Count for Weft
    // if(document.getElementById("yarn_count_weft_cond1").value == "")
    // {
    //     missing_alert("yarn_count_weft_cond1");
    //     return false;
    // }
    // if(document.getElementById("yarn_count_weft_value1").value == "")
    // {
    //     missing_alert("yarn_count_weft_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("yarn_count_weft_value1").value))
    // {
    //     number_alert("yarn_count_weft_value1");
    //     return false;
    // }
    // if(document.getElementById("yarn_count_weft_value2").value == "")
    // {
    //     missing_alert("yarn_count_weft_value2");
    //     return false;
    // }
    // if(isNaN(document.getElementById("yarn_count_weft_value2").value))
    // {
    //     number_alert("yarn_count_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("yarn_count_weft_cond1").value == 1 && (parseFloat(document.getElementById("yarn_count_weft_value2").value)) <= (parseFloat(document.getElementById("yarn_count_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "yarn_count_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("yarn_count_weft_cond1").value == 2 && (parseFloat(document.getElementById("yarn_count_weft_value2").value)) < (parseFloat(document.getElementById("yarn_count_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "yarn_count_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("yarn_count_weft_cond2").value == "")
    // {
    //     missing_alert("yarn_count_weft_cond2");
    //     return false;
    // }


    // //start Number of Threads Warp
    // if(document.getElementById("number_thread_warp_cond1").value == "")
    // {
    //     missing_alert("number_thread_warp_cond1");
    //     return false;
    // }
    // if(document.getElementById("number_thread_warp_value1").value == "")
    // {
    //     missing_alert("number_thread_warp_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("number_thread_warp_value1").value))
    // {
    //     number_alert("number_thread_warp_value1");
    //     return false;
    // }
    // if(document.getElementById("number_thread_warp_value2").value == "")
    // {
    //     missing_alert("number_thread_warp_value2");
    //     return false;
    // }
    // if(isNaN(document.getElementById("number_thread_warp_value2").value))
    // {
    //     number_alert("number_thread_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("number_thread_warp_cond1").value == 1 && (parseFloat(document.getElementById("number_thread_warp_value2").value)) <= (parseFloat(document.getElementById("number_thread_warp_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "number_thread_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("number_thread_warp_cond1").value == 2 && (parseFloat(document.getElementById("number_thread_warp_value2").value)) < (parseFloat(document.getElementById("number_thread_warp_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "number_thread_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("number_thread_warp_cond2").value == "")
    // {
    //     missing_alert("number_thread_warp_cond2");
    //     return false;
    // }


    // //start Number of Threads weft
    // if(document.getElementById("number_thread_weft_cond1").value == "")
    // {
    //     missing_alert("number_thread_weft_cond1");
    //     return false;
    // }
    // if(document.getElementById("number_thread_weft_value1").value == "")
    // {
    //     missing_alert("number_thread_weft_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("number_thread_weft_value1").value))
    // {
    //     number_alert("number_thread_weft_value1");
    //     return false;
    // }
    // if(document.getElementById("number_thread_weft_value2").value == "")
    // {
    //     missing_alert("number_thread_weft_value2");
    //     return false;
    // }
    // if(isNaN(document.getElementById("number_thread_weft_value2").value))
    // {
    //     number_alert("number_thread_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("number_thread_weft_cond1").value == 1 && (parseFloat(document.getElementById("number_thread_weft_value2").value)) <= (parseFloat(document.getElementById("number_thread_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "number_thread_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("number_thread_weft_cond1").value == 2 && (parseFloat(document.getElementById("number_thread_weft_value2").value)) < (parseFloat(document.getElementById("number_thread_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "number_thread_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("number_thread_weft_cond2").value == "")
    // {
    //     missing_alert("number_thread_weft_cond2");
    //     return false;
    // }


    // //start Number of Threads weft
    // if(document.getElementById("number_thread_weft_cond1").value == "")
    // {
    //     missing_alert("number_thread_weft_cond1");
    //     return false;
    // }
    // if(document.getElementById("number_thread_weft_value1").value == "")
    // {
    //     missing_alert("number_thread_weft_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("number_thread_weft_value1").value))
    // {
    //     number_alert("number_thread_weft_value1");
    //     return false;
    // }
    // if(document.getElementById("number_thread_weft_value2").value == "")
    // {
    //     missing_alert("number_thread_weft_value2");
    //     return false;
    // }
    // if(isNaN(document.getElementById("number_thread_weft_value2").value))
    // {
    //     number_alert("number_thread_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("number_thread_weft_cond1").value == 1 && (parseFloat(document.getElementById("number_thread_weft_value2").value)) <= (parseFloat(document.getElementById("number_thread_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "number_thread_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("number_thread_weft_cond1").value == 2 && (parseFloat(document.getElementById("number_thread_weft_value2").value)) < (parseFloat(document.getElementById("number_thread_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "number_thread_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("number_thread_weft_cond2").value == "")
    // {
    //     missing_alert("number_thread_weft_cond2");
    //     return false;
    // }


    // //start Mass per Unit per Area
    // if(document.getElementById("mass_per_unit_per_area_cond1").value == "")
    // {
    //     missing_alert("mass_per_unit_per_area_cond1");
    //     return false;
    // }
    // if(document.getElementById("mass_per_unit_per_area_value1").value == "")
    // {
    //     missing_alert("mass_per_unit_per_area_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("mass_per_unit_per_area_value1").value))
    // {
    //     number_alert("mass_per_unit_per_area_value1");
    //     return false;
    // }
    // if(document.getElementById("mass_per_unit_per_area_value2").value == "")
    // {
    //     missing_alert("mass_per_unit_per_area_value2");
    //     return false;
    // }
    // if(isNaN(document.getElementById("mass_per_unit_per_area_value2").value))
    // {
    //     number_alert("mass_per_unit_per_area_value2");
    //     return false;
    // }
    // if(document.getElementById("mass_per_unit_per_area_cond1").value == 1 && (parseFloat(document.getElementById("mass_per_unit_per_area_value2").value)) <= (parseFloat(document.getElementById("mass_per_unit_per_area_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "mass_per_unit_per_area_value2");
    //     return false;
    // }
    // if(document.getElementById("mass_per_unit_per_area_cond1").value == 2 && (parseFloat(document.getElementById("mass_per_unit_per_area_value2").value)) < (parseFloat(document.getElementById("mass_per_unit_per_area_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "mass_per_unit_per_area_value2");
    //     return false;
    // }
    // if(document.getElementById("mass_per_unit_per_area_cond2").value == "")
    // {
    //     missing_alert("mass_per_unit_per_area_cond2");
    //     return false;
    // }


    // //start Surface Fuzzing & to Pilling
    // if(isNaN(document.getElementById("surface_pilling_value1").value))
    // {
    //     number_alert("surface_pilling_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("surface_pilling_value2").value))
    // {
    //     number_alert("surface_pilling_value2");
    //     return false;
    // }
    // if(document.getElementById("surface_pilling_cond1").value == 1 && (parseFloat(document.getElementById("surface_pilling_value2").value)) <= (parseFloat(document.getElementById("surface_pilling_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "surface_pilling_value2");
    //     return false;
    // }
    // if(document.getElementById("surface_pilling_cond1").value == 2 && (parseFloat(document.getElementById("surface_pilling_value2").value)) < (parseFloat(document.getElementById("surface_pilling_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "surface_pilling_value2");
    //     return false;
    // }


    // //start Tensile Properties Warp
    // if(isNaN(document.getElementById("tensile_warp_value1").value))
    // {
    //     number_alert("tensile_warp_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("tensile_warp_value2").value))
    // {
    //     number_alert("tensile_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("tensile_warp_cond1").value == 1 && (parseFloat(document.getElementById("tensile_warp_value2").value)) <= (parseFloat(document.getElementById("tensile_warp_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "tensile_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("tensile_warp_cond1").value == 2 && (parseFloat(document.getElementById("tensile_warp_value2").value)) < (parseFloat(document.getElementById("tensile_warp_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "tensile_warp_value2");
    //     return false;
    // }


    // //start Tensile Properties weft
    // if(isNaN(document.getElementById("tensile_weft_value1").value))
    // {
    //     number_alert("tensile_weft_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("tensile_weft_value2").value))
    // {
    //     number_alert("tensile_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("tensile_weft_cond1").value == 1 && (parseFloat(document.getElementById("tensile_weft_value2").value)) <= (parseFloat(document.getElementById("tensile_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "tensile_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("tensile_weft_cond1").value == 2 && (parseFloat(document.getElementById("tensile_weft_value2").value)) < (parseFloat(document.getElementById("tensile_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "tensile_weft_value2");
    //     return false;
    // }


    // //start  Tear Force Warp
    // if(isNaN(document.getElementById("tear_force_warp_value1").value))
    // {
    //     number_alert("tear_force_warp_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("tear_force_warp_value2").value))
    // {
    //     number_alert("tear_force_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("tear_force_warp_cond1").value == 1 && (parseFloat(document.getElementById("tear_force_warp_value2").value)) <= (parseFloat(document.getElementById("tear_force_warp_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "tear_force_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("tear_force_warp_cond1").value == 2 && (parseFloat(document.getElementById("tear_force_warp_value2").value)) < (parseFloat(document.getElementById("tear_force_warp_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "tear_force_warp_value2");
    //     return false;
    // }


    // //start Tear Force weft
    // if(isNaN(document.getElementById("tear_force_weft_value1").value))
    // {
    //     number_alert("tear_force_weft_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("tear_force_weft_value2").value))
    // {
    //     number_alert("tear_force_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("tear_force_weft_cond1").value == 1 && (parseFloat(document.getElementById("tear_force_weft_value2").value)) <= (parseFloat(document.getElementById("tear_force_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "tear_force_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("tear_force_weft_cond1").value == 2 && (parseFloat(document.getElementById("tear_force_weft_value2").value)) < (parseFloat(document.getElementById("tear_force_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "tear_force_weft_value2");
    //     return false;
    // }


    // //start Seam Strength Warp
    // if(isNaN(document.getElementById("seam_strength_warp_value1").value))
    // {
    //     number_alert("seam_strength_warp_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("seam_strength_warp_value2").value))
    // {
    //     number_alert("seam_strength_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("seam_strength_warp_cond1").value == 1 && (parseFloat(document.getElementById("seam_strength_warp_value2").value)) <= (parseFloat(document.getElementById("seam_strength_warp_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "seam_strength_warp_value2");
    //     return false;
    // }
    // if(document.getElementById("seam_strength_warp_cond1").value == 2 && (parseFloat(document.getElementById("seam_strength_warp_value2").value)) < (parseFloat(document.getElementById("seam_strength_warp_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "seam_strength_warp_value2");
    //     return false;
    // }


    // //start Seam Strength Weft
    // if(isNaN(document.getElementById("seam_strength_weft_value1").value))
    // {
    //     number_alert("seam_strength_weft_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("seam_strength_weft_value2").value))
    // {
    //     number_alert("seam_strength_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("seam_strength_weft_cond1").value == 1 && (parseFloat(document.getElementById("seam_strength_weft_value2").value)) <= (parseFloat(document.getElementById("seam_strength_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "seam_strength_weft_value2");
    //     return false;
    // }
    // if(document.getElementById("seam_strength_weft_cond1").value == 2 && (parseFloat(document.getElementById("seam_strength_weft_value2").value)) < (parseFloat(document.getElementById("seam_strength_weft_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "seam_strength_weft_value2");
    //     return false;
    // }


    // //start Abrasion Resistance S.Change
    // if(isNaN(document.getElementById("abrasion_resistance_value1").value))
    // {
    //     number_alert("abrasion_resistance_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("abrasion_resistance_value2").value))
    // {
    //     number_alert("abrasion_resistance_value2");
    //     return false;
    // }
    // if(document.getElementById("abrasion_resistance_cond1").value == 1 && (parseFloat(document.getElementById("abrasion_resistance_value2").value)) <= (parseFloat(document.getElementById("abrasion_resistance_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "abrasion_resistance_value2");
    //     return false;
    // }
    // if(document.getElementById("abrasion_resistance_cond1").value == 2 && (parseFloat(document.getElementById("abrasion_resistance_value2").value)) < (parseFloat(document.getElementById("abrasion_resistance_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "abrasion_resistance_value2");
    //     return false;
    // }


    // //start Abrasion Resistance Thread Break
    // // if(document.getElementById("abrasion_resistance_thread_break").value == "")
    // // {
    // //     missing_alert("abrasion_resistance_thread_break");
    // //     return false;
    // // }

    // //start Revolution
    // // if(document.getElementById("revolution").value == "")
    // // {
    // //     missing_alert("revolution");
    // //     return false;
    // // }


    // //start Mass Loss in Abrasion test
    // if(isNaN(document.getElementById("abrasion_resistance_lose_value1").value))
    // {
    //     number_alert("abrasion_resistance_lose_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("abrasion_resistance_lose_value2").value))
    // {
    //     number_alert("abrasion_resistance_lose_value2");
    //     return false;
    // }
    // if(document.getElementById("abrasion_resistance_lose_cond1").value == 1 && (parseFloat(document.getElementById("abrasion_resistance_lose_value2").value)) <= (parseFloat(document.getElementById("abrasion_resistance_lose_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "abrasion_resistance_lose_value2");
    //     return false;
    // }
    // if(document.getElementById("abrasion_resistance_lose_cond1").value == 2 && (parseFloat(document.getElementById("abrasion_resistance_lose_value2").value)) < (parseFloat(document.getElementById("abrasion_resistance_lose_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "abrasion_resistance_lose_value2");
    //     return false;
    // }


    // //start pH
    // if(document.getElementById("washing_ph_cond1").value == "")
    // {
    //     missing_alert("washing_ph_cond1");
    //     return false;
    // }
    // if(document.getElementById("washing_ph_value1").value == "")
    // {
    //     missing_alert("washing_ph_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("washing_ph_value1").value))
    // {
    //     number_alert("washing_ph_value1");
    //     return false;
    // }
    // if(document.getElementById("washing_ph_value2").value == "")
    // {
    //     missing_alert("washing_ph_value2");
    //     return false;
    // }
    // if(isNaN(document.getElementById("washing_ph_value2").value))
    // {
    //     number_alert("washing_ph_value2");
    //     return false;
    // }
    // if(document.getElementById("washing_ph_cond1").value == 1 && (parseFloat(document.getElementById("washing_ph_value2").value)) <= (parseFloat(document.getElementById("washing_ph_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "washing_ph_value2");
    //     return false;
    // }
    // if(document.getElementById("washing_ph_cond1").value == 2 && (parseFloat(document.getElementById("washing_ph_value2").value)) < (parseFloat(document.getElementById("washing_ph_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "washing_ph_value2");
    //     return false;
    // }
    // if(document.getElementById("washing_ph_cond2").value == "")
    // {
    //     missing_alert("washing_ph_cond2");
    //     return false;
    // }


    // //start Formaldehyde Content (PPM)
    // if(document.getElementById("formaldehyde_content_cond1").value == "")
    // {
    //     missing_alert("formaldehyde_content_cond1");
    //     return false;
    // }
    // if(document.getElementById("formaldehyde_content_value1").value == "")
    // {
    //     missing_alert("formaldehyde_content_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("formaldehyde_content_value1").value))
    // {
    //     number_alert("formaldehyde_content_value1");
    //     return false;
    // }
    // if(document.getElementById("formaldehyde_content_value2").value == "")
    // {
    //     missing_alert("formaldehyde_content_value2");
    //     return false;
    // }
    // if(isNaN(document.getElementById("formaldehyde_content_value2").value))
    // {
    //     number_alert("formaldehyde_content_value2");
    //     return false;
    // }
    // if(document.getElementById("formaldehyde_content_cond1").value == 1 && (parseFloat(document.getElementById("formaldehyde_content_value2").value)) <= (parseFloat(document.getElementById("formaldehyde_content_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "formaldehyde_content_value2");
    //     return false;
    // }
    // if(document.getElementById("formaldehyde_content_cond1").value == 2 && (parseFloat(document.getElementById("formaldehyde_content_value2").value)) < (parseFloat(document.getElementById("formaldehyde_content_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "formaldehyde_content_value2");
    //     return false;
    // }
    // if(document.getElementById("formaldehyde_content_cond2").value == "")
    // {
    //     missing_alert("formaldehyde_content_cond2");
    //     return false;
    // }


    // //start Color Fastness to Dry Cleaning Color Change
    // if(isNaN(document.getElementById("cf_dry_cleaning_c_change_value1").value))
    // {
    //     number_alert("cf_dry_cleaning_c_change_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_dry_cleaning_c_change_value2").value))
    // {
    //     number_alert("cf_dry_cleaning_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_dry_cleaning_c_change_cond1").value == 1 && (parseFloat(document.getElementById("cf_dry_cleaning_c_change_value2").value)) <= (parseFloat(document.getElementById("cf_dry_cleaning_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_dry_cleaning_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_dry_cleaning_c_change_cond1").value == 2 && (parseFloat(document.getElementById("cf_dry_cleaning_c_change_value2").value)) < (parseFloat(document.getElementById("cf_dry_cleaning_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_dry_cleaning_c_change_value2");
    //     return false;
    // }


    // //start Color Fastness to Dry Cleaning Staining
    // if(isNaN(document.getElementById("cf_dry_cleaning_staining_value1").value))
    // {
    //     number_alert("cf_dry_cleaning_staining_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_dry_cleaning_staining_value2").value))
    // {
    //     number_alert("cf_dry_cleaning_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_dry_cleaning_staining_cond1").value == 1 && (parseFloat(document.getElementById("cf_dry_cleaning_staining_value2").value)) <= (parseFloat(document.getElementById("cf_dry_cleaning_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_dry_cleaning_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_dry_cleaning_staining_cond1").value == 2 && (parseFloat(document.getElementById("cf_dry_cleaning_staining_value2").value)) < (parseFloat(document.getElementById("cf_dry_cleaning_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_dry_cleaning_staining_value2");
    //     return false;
    // }


    // //start Color Fastness to Washing Color Change
    // if(isNaN(document.getElementById("cf_washing_c_change_value1").value))
    // {
    //     number_alert("cf_washing_c_change_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_washing_c_change_value2").value))
    // {
    //     number_alert("cf_washing_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_washing_c_change_cond1").value == 1 && (parseFloat(document.getElementById("cf_washing_c_change_value2").value)) <= (parseFloat(document.getElementById("cf_washing_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_washing_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_washing_c_change_cond1").value == 2 && (parseFloat(document.getElementById("cf_washing_c_change_value2").value)) < (parseFloat(document.getElementById("cf_washing_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_washing_c_change_value2");
    //     return false;
    // }


    // //start Color Fastness to Washing Staining
    // if(isNaN(document.getElementById("cf_washing_staining_value1").value))
    // {
    //     number_alert("cf_washing_staining_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_washing_staining_value2").value))
    // {
    //     number_alert("cf_washing_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_washing_staining_cond1").value == 1 && (parseFloat(document.getElementById("cf_washing_staining_value2").value)) <= (parseFloat(document.getElementById("cf_washing_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_washing_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_washing_staining_cond1").value == 2 && (parseFloat(document.getElementById("cf_washing_staining_value2").value)) < (parseFloat(document.getElementById("cf_washing_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_washing_staining_value2");
    //     return false;
    // }


    // //start Color Fastness to Perspiration (Acid) Color Change
    // if(isNaN(document.getElementById("cf_perspiration_acis_c_change_value1").value))
    // {
    //     number_alert("cf_perspiration_acis_c_change_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_perspiration_acis_c_change_value2").value))
    // {
    //     number_alert("cf_perspiration_acis_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_perspiration_acis_c_change_cond1").value == 1 && (parseFloat(document.getElementById("cf_perspiration_acis_c_change_value2").value)) <= (parseFloat(document.getElementById("cf_perspiration_acis_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_perspiration_acis_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_perspiration_acis_c_change_cond1").value == 2 && (parseFloat(document.getElementById("cf_perspiration_acis_c_change_value2").value)) < (parseFloat(document.getElementById("cf_perspiration_acis_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_perspiration_acis_c_change_value2");
    //     return false;
    // }


    // //start Color Fastness to Perspiration (Acid) Staining
    // if(isNaN(document.getElementById("cf_perspiration_acis_staining_value1").value))
    // {
    //     number_alert("cf_perspiration_acis_staining_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_perspiration_acis_staining_value2").value))
    // {
    //     number_alert("cf_perspiration_acis_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_perspiration_acis_staining_cond1").value == 1 && (parseFloat(document.getElementById("cf_perspiration_acis_staining_value2").value)) <= (parseFloat(document.getElementById("cf_perspiration_acis_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_perspiration_acis_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_perspiration_acis_staining_cond1").value == 2 && (parseFloat(document.getElementById("cf_perspiration_acis_staining_value2").value)) < (parseFloat(document.getElementById("cf_perspiration_acis_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_perspiration_acis_staining_value2");
    //     return false;
    // }


    // //start Color Fastness to Perspiration (Alkali) Color Change
    // if(isNaN(document.getElementById("cf_perspiration_alkali_c_change_value1").value))
    // {
    //     number_alert("cf_perspiration_alkali_c_change_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_perspiration_alkali_c_change_value2").value))
    // {
    //     number_alert("cf_perspiration_alkali_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_perspiration_alkali_c_change_cond1").value == 1 && (parseFloat(document.getElementById("cf_perspiration_alkali_c_change_value2").value)) <= (parseFloat(document.getElementById("cf_perspiration_alkali_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_perspiration_alkali_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_perspiration_alkali_c_change_cond1").value == 2 && (parseFloat(document.getElementById("cf_perspiration_alkali_c_change_value2").value)) < (parseFloat(document.getElementById("cf_perspiration_alkali_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_perspiration_alkali_c_change_value2");
    //     return false;
    // }


    // //start Color Fastness to Perspiration (Alkali) Staining
    // if(isNaN(document.getElementById("cf_perspiration_alkali_staining_value1").value))
    // {
    //     number_alert("cf_perspiration_alkali_staining_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_perspiration_alkali_staining_value2").value))
    // {
    //     number_alert("cf_perspiration_alkali_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_perspiration_alkali_staining_cond1").value == 1 && (parseFloat(document.getElementById("cf_perspiration_alkali_staining_value2").value)) <= (parseFloat(document.getElementById("cf_perspiration_alkali_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_perspiration_alkali_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_perspiration_alkali_staining_cond1").value == 2 && (parseFloat(document.getElementById("cf_perspiration_alkali_staining_value2").value)) < (parseFloat(document.getElementById("cf_perspiration_alkali_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_perspiration_alkali_staining_value2");
    //     return false;
    // }


    // //start Color Fastness to Water Color Change
    // if(isNaN(document.getElementById("cf_water_c_change_value1").value))
    // {
    //     number_alert("cf_water_c_change_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_water_c_change_value2").value))
    // {
    //     number_alert("cf_water_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_water_c_change_cond1").value == 1 && (parseFloat(document.getElementById("cf_water_c_change_value2").value)) <= (parseFloat(document.getElementById("cf_water_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_water_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_water_c_change_cond1").value == 2 && (parseFloat(document.getElementById("cf_water_c_change_value2").value)) < (parseFloat(document.getElementById("cf_water_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_water_c_change_value2");
    //     return false;
    // }


    // //start Color Fastness to Water Staining
    // if(isNaN(document.getElementById("cf_water_staining_value1").value))
    // {
    //     number_alert("cf_water_staining_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_water_staining_value2").value))
    // {
    //     number_alert("cf_water_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_water_staining_cond1").value == 1 && (parseFloat(document.getElementById("cf_water_staining_value2").value)) <= (parseFloat(document.getElementById("cf_water_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_water_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_water_staining_cond1").value == 2 && (parseFloat(document.getElementById("cf_water_staining_value2").value)) < (parseFloat(document.getElementById("cf_water_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_water_staining_value2");
    //     return false;
    // }


    // //start Color Fastness to Water Sotting Staining
    // if(isNaN(document.getElementById("cf_water_sotting_staining_value1").value))
    // {
    //     number_alert("cf_water_sotting_staining_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_water_sotting_staining_value2").value))
    // {
    //     number_alert("cf_water_sotting_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_water_sotting_staining_cond1").value == 1 && (parseFloat(document.getElementById("cf_water_sotting_staining_value2").value)) <= (parseFloat(document.getElementById("cf_water_sotting_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_water_sotting_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_water_sotting_staining_cond1").value == 2 && (parseFloat(document.getElementById("cf_water_sotting_staining_value2").value)) < (parseFloat(document.getElementById("cf_water_sotting_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_water_sotting_staining_value2");
    //     return false;
    // }


    // //start Color Fastness to Water Wetting Staining
    // if(isNaN(document.getElementById("cf_water_wetting_staining_value1").value))
    // {
    //     number_alert("cf_water_wetting_staining_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_water_wetting_staining_value2").value))
    // {
    //     number_alert("cf_water_wetting_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_water_wetting_staining_cond1").value == 1 && (parseFloat(document.getElementById("cf_water_wetting_staining_value2").value)) <= (parseFloat(document.getElementById("cf_water_wetting_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_water_wetting_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_water_wetting_staining_cond1").value == 2 && (parseFloat(document.getElementById("cf_water_wetting_staining_value2").value)) < (parseFloat(document.getElementById("cf_water_wetting_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_water_wetting_staining_value2");
    //     return false;
    // }


    // //start Color Fastness to Hydrolysis of Reactive Dyes Color Change
    // if(isNaN(document.getElementById("cf_hyd_reactive_dyes_c_change_value1").value))
    // {
    //     number_alert("cf_hyd_reactive_dyes_c_change_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_hyd_reactive_dyes_c_change_value2").value))
    // {
    //     number_alert("cf_hyd_reactive_dyes_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_hyd_reactive_dyes_c_change_cond1").value == 1 && (parseFloat(document.getElementById("cf_hyd_reactive_dyes_c_change_value2").value)) <= (parseFloat(document.getElementById("cf_hyd_reactive_dyes_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_hyd_reactive_dyes_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_hyd_reactive_dyes_c_change_cond1").value == 2 && (parseFloat(document.getElementById("cf_hyd_reactive_dyes_c_change_value2").value)) < (parseFloat(document.getElementById("cf_hyd_reactive_dyes_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_hyd_reactive_dyes_c_change_value2");
    //     return false;
    // }



    // //start Color Fastness to Hydrolysis of Reactive Dyes Staining
    // if(isNaN(document.getElementById("cf_hyd_reactive_dyes_staining_value1").value))
    // {
    //     number_alert("cf_hyd_reactive_dyes_staining_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_hyd_reactive_dyes_staining_value2").value))
    // {
    //     number_alert("cf_hyd_reactive_dyes_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_hyd_reactive_dyes_staining_cond1").value == 1 && (parseFloat(document.getElementById("cf_hyd_reactive_dyes_staining_value2").value)) <= (parseFloat(document.getElementById("cf_hyd_reactive_dyes_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_hyd_reactive_dyes_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_hyd_reactive_dyes_staining_cond1").value == 2 && (parseFloat(document.getElementById("cf_hyd_reactive_dyes_staining_value2").value)) < (parseFloat(document.getElementById("cf_hyd_reactive_dyes_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_hyd_reactive_dyes_staining_value2");
    //     return false;
    // }


    // //start Color Fastness to Oidative Bleach Damage Color Change
    // if(isNaN(document.getElementById("cf_oidative_damage_c_change_value1").value))
    // {
    //     number_alert("cf_oidative_damage_c_change_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_oidative_damage_c_change_value2").value))
    // {
    //     number_alert("cf_oidative_damage_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_oidative_damage_c_change_cond1").value == 1 && (parseFloat(document.getElementById("cf_oidative_damage_c_change_value2").value)) <= (parseFloat(document.getElementById("cf_oidative_damage_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_oidative_damage_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_oidative_damage_c_change_cond1").value == 2 && (parseFloat(document.getElementById("cf_oidative_damage_c_change_value2").value)) < (parseFloat(document.getElementById("cf_oidative_damage_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_oidative_damage_c_change_value2");
    //     return false;
    // }


    // //start Color Fastness to Phenolic Yellowing Staining
    // if(isNaN(document.getElementById("cf_phenolic_staining_value1").value))
    // {
    //     number_alert("cf_phenolic_staining_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_phenolic_staining_value2").value))
    // {
    //     number_alert("cf_phenolic_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_phenolic_staining_cond1").value == 1 && (parseFloat(document.getElementById("cf_phenolic_staining_value2").value)) <= (parseFloat(document.getElementById("cf_phenolic_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_phenolic_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_phenolic_staining_cond1").value == 2 && (parseFloat(document.getElementById("cf_phenolic_staining_value2").value)) < (parseFloat(document.getElementById("cf_phenolic_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_phenolic_staining_value2");
    //     return false;
    // }


    // //start Color Fastness to PVC Migration Staining
    // if(isNaN(document.getElementById("cf_pvc_migration_staining_value1").value))
    // {
    //     number_alert("cf_pvc_migration_staining_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_pvc_migration_staining_value2").value))
    // {
    //     number_alert("cf_pvc_migration_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_pvc_migration_staining_cond1").value == 1 && (parseFloat(document.getElementById("cf_pvc_migration_staining_value2").value)) <= (parseFloat(document.getElementById("cf_pvc_migration_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_pvc_migration_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_pvc_migration_staining_cond1").value == 2 && (parseFloat(document.getElementById("cf_pvc_migration_staining_value2").value)) < (parseFloat(document.getElementById("cf_pvc_migration_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_pvc_migration_staining_value2");
    //     return false;
    // }


    // //start Color Fastness to Saliva Color Change
    // if(isNaN(document.getElementById("cf_saliva_c_change_value1").value))
    // {
    //     number_alert("cf_saliva_c_change_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_saliva_c_change_value2").value))
    // {
    //     number_alert("cf_saliva_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_saliva_c_change_cond1").value == 1 && (parseFloat(document.getElementById("cf_saliva_c_change_value2").value)) <= (parseFloat(document.getElementById("cf_saliva_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_saliva_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_saliva_c_change_cond1").value == 2 && (parseFloat(document.getElementById("cf_saliva_c_change_value2").value)) < (parseFloat(document.getElementById("cf_saliva_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_saliva_c_change_value2");
    //     return false;
    // }


    // //start Color Fastness to Saliva Staining
    // if(isNaN(document.getElementById("cf_saliva_staining_value1").value))
    // {
    //     number_alert("cf_saliva_staining_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_saliva_staining_value2").value))
    // {
    //     number_alert("cf_saliva_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_saliva_staining_cond1").value == 1 && (parseFloat(document.getElementById("cf_saliva_staining_value2").value)) <= (parseFloat(document.getElementById("cf_saliva_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_saliva_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_saliva_staining_cond1").value == 2 && (parseFloat(document.getElementById("cf_saliva_staining_value2").value)) < (parseFloat(document.getElementById("cf_saliva_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_saliva_staining_value2");
    //     return false;
    // }


    // //start Color Fastness to Chlorinated Water Color Change
    // if(isNaN(document.getElementById("cf_chlorinated_water_c_change_value1").value))
    // {
    //     number_alert("cf_chlorinated_water_c_change_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_chlorinated_water_c_change_value2").value))
    // {
    //     number_alert("cf_chlorinated_water_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_chlorinated_water_c_change_cond1").value == 1 && (parseFloat(document.getElementById("cf_chlorinated_water_c_change_value2").value)) <= (parseFloat(document.getElementById("cf_chlorinated_water_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_chlorinated_water_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_chlorinated_water_c_change_cond1").value == 2 && (parseFloat(document.getElementById("cf_chlorinated_water_c_change_value2").value)) < (parseFloat(document.getElementById("cf_chlorinated_water_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_chlorinated_water_c_change_value2");
    //     return false;
    // }


    // //start Color Fastness to Chlorinated Water Staining
    // if(isNaN(document.getElementById("cf_chlorinated_water_staining_value1").value))
    // {
    //     number_alert("cf_chlorinated_water_staining_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_chlorinated_water_staining_value2").value))
    // {
    //     number_alert("cf_chlorinated_water_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_chlorinated_water_staining_cond1").value == 1 && (parseFloat(document.getElementById("cf_chlorinated_water_staining_value2").value)) <= (parseFloat(document.getElementById("cf_chlorinated_water_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_chlorinated_water_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_chlorinated_water_staining_cond1").value == 2 && (parseFloat(document.getElementById("cf_chlorinated_water_staining_value2").value)) < (parseFloat(document.getElementById("cf_chlorinated_water_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_chlorinated_water_staining_value2");
    //     return false;
    // }


    // //start Color Fastness to Cholorine Bleach Color Change
    // if(isNaN(document.getElementById("cf_cholorine_bleach_c_change_value1").value))
    // {
    //     number_alert("cf_cholorine_bleach_c_change_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_cholorine_bleach_c_change_value2").value))
    // {
    //     number_alert("cf_cholorine_bleach_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_cholorine_bleach_c_change_cond1").value == 1 && (parseFloat(document.getElementById("cf_cholorine_bleach_c_change_value2").value)) <= (parseFloat(document.getElementById("cf_cholorine_bleach_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_cholorine_bleach_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_cholorine_bleach_c_change_cond1").value == 2 && (parseFloat(document.getElementById("cf_cholorine_bleach_c_change_value2").value)) < (parseFloat(document.getElementById("cf_cholorine_bleach_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_cholorine_bleach_c_change_value2");
    //     return false;
    // }


    // //start Color Fastness to Cholorine Bleach Staining 
    // if(isNaN(document.getElementById("cf_cholorine_bleach_staining_value1").value))
    // {
    //     number_alert("cf_cholorine_bleach_staining_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_cholorine_bleach_staining_value2").value))
    // {
    //     number_alert("cf_cholorine_bleach_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_cholorine_bleach_staining_cond1").value == 1 && (parseFloat(document.getElementById("cf_cholorine_bleach_staining_value2").value)) <= (parseFloat(document.getElementById("cf_cholorine_bleach_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_cholorine_bleach_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_cholorine_bleach_staining_cond1").value == 2 && (parseFloat(document.getElementById("cf_cholorine_bleach_staining_value2").value)) < (parseFloat(document.getElementById("cf_cholorine_bleach_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_cholorine_bleach_staining_value2");
    //     return false;
    // }


    // //start Color Fastness to Peroxide Bleach Color Change
    // if(isNaN(document.getElementById("cf_peroxide_bleach_c_change_value1").value))
    // {
    //     number_alert("cf_peroxide_bleach_c_change_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_peroxide_bleach_c_change_value2").value))
    // {
    //     number_alert("cf_peroxide_bleach_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_peroxide_bleach_c_change_cond1").value == 1 && (parseFloat(document.getElementById("cf_peroxide_bleach_c_change_value2").value)) <= (parseFloat(document.getElementById("cf_peroxide_bleach_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_peroxide_bleach_c_change_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_peroxide_bleach_c_change_cond1").value == 2 && (parseFloat(document.getElementById("cf_peroxide_bleach_c_change_value2").value)) < (parseFloat(document.getElementById("cf_peroxide_bleach_c_change_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_peroxide_bleach_c_change_value2");
    //     return false;
    // }


    // //start Color Fastness to Peroxide Bleach Staining
    // if(isNaN(document.getElementById("cf_peroxide_bleach_staining_value1").value))
    // {
    //     number_alert("cf_peroxide_bleach_staining_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_peroxide_bleach_staining_value2").value))
    // {
    //     number_alert("cf_peroxide_bleach_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_peroxide_bleach_staining_cond1").value == 1 && (parseFloat(document.getElementById("cf_peroxide_bleach_staining_value2").value)) <= (parseFloat(document.getElementById("cf_peroxide_bleach_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_peroxide_bleach_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_peroxide_bleach_staining_cond1").value == 2 && (parseFloat(document.getElementById("cf_peroxide_bleach_staining_value2").value)) < (parseFloat(document.getElementById("cf_peroxide_bleach_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_peroxide_bleach_staining_value2");
    //     return false;
    // }



    // //start Cross Staining
    // if(isNaN(document.getElementById("cross_staining_value1").value))
    // {
    //     number_alert("cross_staining_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cross_staining_value2").value))
    // {
    //     number_alert("cross_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cross_staining_cond1").value == 1 && (parseFloat(document.getElementById("cross_staining_value2").value)) <= (parseFloat(document.getElementById("cross_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cross_staining_value2");
    //     return false;
    // }
    // if(document.getElementById("cross_staining_cond1").value == 2 && (parseFloat(document.getElementById("cross_staining_value2").value)) < (parseFloat(document.getElementById("cross_staining_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cross_staining_value2");
    //     return false;
    // }


    // // //start Color Fastness to Artificial Light Color Change
    // // if(isNaN(document.getElementById("cf_artificial_light_c_change_value1").value))
    // // {
    // //     number_alert("cf_artificial_light_c_change_value1");
    // //     return false;
    // // }
    // // if(isNaN(document.getElementById("cf_artificial_light_c_change_value2").value))
    // // {
    // //     number_alert("cf_artificial_light_c_change_value2");
    // //     return false;
    // // }
    // // if(document.getElementById("cf_artificial_light_c_change_cond1").value == 1 && (parseFloat(document.getElementById("cf_artificial_light_c_change_value2").value)) <= (parseFloat(document.getElementById("cf_artificial_light_c_change_value1").value)))
    // // {
    // //     warning_alert("Should be Bigger", "cf_artificial_light_c_change_value2");
    // //     return false;
    // // }
    // // if(document.getElementById("cf_artificial_light_c_change_cond1").value == 2 && (parseFloat(document.getElementById("cf_artificial_light_c_change_value2").value)) < (parseFloat(document.getElementById("cf_artificial_light_c_change_value1").value)))
    // // {
    // //     warning_alert("Should be Bigger or Equal", "cf_artificial_light_c_change_value2");
    // //     return false;
    // // }

    // //start Water absorption
    // if(isNaN(document.getElementById("water_absorption_value1").value))
    // {
    //     number_alert("water_absorption_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("water_absorption_value2").value))
    // {
    //     number_alert("water_absorption_value2");
    //     return false;
    // }
    // if(document.getElementById("water_absorption_cond1").value == 1 && (parseFloat(document.getElementById("water_absorption_value2").value)) <= (parseFloat(document.getElementById("water_absorption_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "water_absorption_value2");
    //     return false;
    // }
    // if(document.getElementById("water_absorption_cond1").value == 2 && (parseFloat(document.getElementById("water_absorption_value2").value)) < (parseFloat(document.getElementById("water_absorption_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "water_absorption_value2");
    //     return false;
    // }


    // //start Spirality (%)
    // if(isNaN(document.getElementById("spirality_value1").value))
    // {
    //     number_alert("spirality_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("spirality_value2").value))
    // {
    //     number_alert("spirality_value2");
    //     return false;
    // }
    // if(document.getElementById("spirality_cond1").value == 1 && (parseFloat(document.getElementById("spirality_value2").value)) <= (parseFloat(document.getElementById("spirality_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "spirality_value2");
    //     return false;
    // }
    // if(document.getElementById("spirality_cond1").value == 2 && (parseFloat(document.getElementById("spirality_value2").value)) < (parseFloat(document.getElementById("spirality_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "spirality_value2");
    //     return false;
    // }


    // //start Durable Press
    // if(isNaN(document.getElementById("durable_press_value1").value))
    // {
    //     number_alert("durable_press_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("durable_press_value2").value))
    // {
    //     number_alert("durable_press_value2");
    //     return false;
    // }
    // if(document.getElementById("durable_press_cond1").value == 1 && (parseFloat(document.getElementById("durable_press_value2").value)) <= (parseFloat(document.getElementById("durable_press_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "durable_press_value2");
    //     return false;
    // }
    // if(document.getElementById("durable_press_cond1").value == 2 && (parseFloat(document.getElementById("durable_press_value2").value)) < (parseFloat(document.getElementById("durable_press_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "durable_press_value2");
    //     return false;
    // }


    // //start Ironability of Woven Fabric
    // if(isNaN(document.getElementById("ironability_value1").value))
    // {
    //     number_alert("ironability_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("ironability_value2").value))
    // {
    //     number_alert("ironability_value2");
    //     return false;
    // }
    // if(document.getElementById("ironability_cond1").value == 1 && (parseFloat(document.getElementById("ironability_value2").value)) <= (parseFloat(document.getElementById("ironability_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "ironability_value2");
    //     return false;
    // }
    // if(document.getElementById("ironability_cond1").value == 2 && (parseFloat(document.getElementById("ironability_value2").value)) < (parseFloat(document.getElementById("ironability_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "ironability_value2");
    //     return false;
    // }


    // //start Color Fastness to Artificial Light
    // if(isNaN(document.getElementById("cf_artificial_light_value1").value))
    // {
    //     number_alert("cf_artificial_light_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("cf_artificial_light_value2").value))
    // {
    //     number_alert("cf_artificial_light_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_artificial_light_cond1").value == 1 && (parseFloat(document.getElementById("cf_artificial_light_value2").value)) <= (parseFloat(document.getElementById("cf_artificial_light_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "cf_artificial_light_value2");
    //     return false;
    // }
    // if(document.getElementById("cf_artificial_light_cond1").value == 2 && (parseFloat(document.getElementById("cf_artificial_light_value2").value)) < (parseFloat(document.getElementById("cf_artificial_light_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "cf_artificial_light_value2");
    //     return false;
    // }


    // //start Moisture Content
    // if(isNaN(document.getElementById("moisture_content_value1").value))
    // {
    //     number_alert("moisture_content_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("moisture_content_value2").value))
    // {
    //     number_alert("moisture_content_value2");
    //     return false;
    // }
    // if(document.getElementById("moisture_content_cond1").value == 1 && (parseFloat(document.getElementById("moisture_content_value2").value)) <= (parseFloat(document.getElementById("moisture_content_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "moisture_content_value2");
    //     return false;
    // }
    // if(document.getElementById("moisture_content_cond1").value == 2 && (parseFloat(document.getElementById("moisture_content_value2").value)) < (parseFloat(document.getElementById("moisture_content_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "moisture_content_value2");
    //     return false;
    // }


    // //start Evaporation Rate
    // if(isNaN(document.getElementById("evaporation_rate_value1").value))
    // {
    //     number_alert("evaporation_rate_value1");
    //     return false;
    // }
    // if(isNaN(document.getElementById("evaporation_rate_value2").value))
    // {
    //     number_alert("evaporation_rate_value2");
    //     return false;
    // }
    // if(document.getElementById("evaporation_rate_cond1").value == 1 && (parseFloat(document.getElementById("evaporation_rate_value2").value)) <= (parseFloat(document.getElementById("evaporation_rate_value1").value)))
    // {
    //     warning_alert("Should be Bigger", "evaporation_rate_value2");
    //     return false;
    // }
    // if(document.getElementById("evaporation_rate_cond1").value == 2 && (parseFloat(document.getElementById("evaporation_rate_value2").value)) < (parseFloat(document.getElementById("evaporation_rate_value1").value)))
    // {
    //     warning_alert("Should be Bigger or Equal", "evaporation_rate_value2");
    //     return false;
    // }



    // if ((document.getElementsByName("fiber_content")[0].checked) || (document.getElementsByName("fiber_content")[1].checked) || (document.getElementsByName("fiber_content")[2].checked) )
    // {
    //     update_check = document.getElementById("update").value;
    //     //check not more than 100 or less than 100
    //     var fiber_content_selected_for_number = parseInt(document.getElementById("fiber_content_selected_for_number").value);

    //     if (update_check == "yes") 
    //     {
    //         if (fiber_content_selected_for_number == 1) 
    //         {
    //             if ( (document.getElementById("fiber_total_polyester_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_total_cotton_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_total_thired_tol_value1").value != "") ||
    //                 (document.getElementById("fiber_total_fourth_tol_value1").value != "") )
    //             {
    //                 var total_fiber_content = 0;
    //                 var total_polyester_value = parseInt(document.getElementById("fiber_total_polyester_tol_value1").value);
    //                 var total_cotton_value = parseInt(document.getElementById("fiber_total_cotton_tol_value1").value);
    //                 var total_thired_value = parseInt(document.getElementById("fiber_total_thired_tol_value1").value);
    //                 var total_fourth_value = parseInt(document.getElementById("fiber_total_fourth_tol_value1").value);

    //                 var total_polyester = isNaN(total_polyester_value) ? 0 : total_polyester_value;
    //                 var total_cotton = isNaN(total_cotton_value) ? 0 : total_cotton_value;
    //                 var total_thired = isNaN(total_thired_value) ? 0 : total_thired_value;
    //                 var total_fourth = isNaN(total_fourth_value) ? 0 : total_fourth_value;

    //                 total_fiber_content = total_polyester + total_cotton + total_thired + total_fourth;

    //                 if (total_fiber_content != 100)
    //                 {
    //                     info_alert("Make sure Fiber Total value result exactly 100");
    //                     return false;
    //                 }
    //             }
                    
    //         }


    //         else if (fiber_content_selected_for_number == 2) 
    //         {
    //             if ( (document.getElementById("fiber_warp_polyester_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_warp_cotton_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_warp_thired_tol_value1").value != "") ||
    //                 (document.getElementById("fiber_warp_fourth_tol_value1").value != "") )
    //             {
    //                 var total_warp_fiber_content = 0;
    //                 var total_warp_polyester_value = parseInt(document.getElementById("fiber_warp_polyester_tol_value1").value);
    //                 var total_warp_cotton_value = parseInt(document.getElementById("fiber_warp_cotton_tol_value1").value);
    //                 var total_warp_thired_value = parseInt(document.getElementById("fiber_warp_thired_tol_value1").value);
    //                 var total_warp_fourth_value = parseInt(document.getElementById("fiber_warp_fourth_tol_value1").value);

    //                 var total_warp_polyester = isNaN(total_warp_polyester_value) ? 0 : total_warp_polyester_value;
    //                 var total_warp_cotton = isNaN(total_warp_cotton_value) ? 0 : total_warp_cotton_value;
    //                 var total_warp_thired = isNaN(total_warp_thired_value) ? 0 : total_warp_thired_value;
    //                 var total_warp_fourth = isNaN(total_warp_fourth_value) ? 0 : total_warp_fourth_value;

    //                 total_warp_fiber_content = total_warp_polyester + total_warp_cotton + total_warp_thired + total_warp_fourth;

    //                 if (total_warp_fiber_content != 100)
    //                 {
    //                     info_alert("Make sure Fiber Wrap all value result exactly 100");
    //                     return false;
    //                 }
    //             }


    //             if ( (document.getElementById("fiber_weft_polyester_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_weft_cotton_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_weft_thired_tol_value1").value != "") ||
    //                 (document.getElementById("fiber_weft_fourth_tol_value1").value != "") )
    //             {
    //                 var total_weft_fiber_content = 0;

    //                 var total_weft_polyester_value = parseInt(document.getElementById("fiber_weft_polyester_tol_value1").value);
    //                 var total_weft_cotton_value = parseInt(document.getElementById("fiber_weft_cotton_tol_value1").value);
    //                 var total_weft_thired_value = parseInt(document.getElementById("fiber_weft_thired_tol_value1").value);
    //                 var total_weft_fourth_value = parseInt(document.getElementById("fiber_weft_fourth_tol_value1").value);

    //                 var total_weft_polyester = isNaN(total_weft_polyester_value) ? 0 : total_weft_polyester_value;
    //                 var total_weft_cotton = isNaN(total_weft_cotton_value) ? 0 : total_weft_cotton_value;
    //                 var total_weft_thired = isNaN(total_weft_thired_value) ? 0 : total_weft_thired_value;
    //                 var total_weft_fourth = isNaN(total_weft_fourth_value) ? 0 : total_weft_fourth_value;

    //                 total_weft_fiber_content = total_weft_polyester + total_weft_cotton + total_weft_thired + total_weft_fourth;

    //                 if (total_weft_fiber_content != 100)
    //                 {
    //                     info_alert("Make sure Fiber Weft all value result exactly 100");
    //                     return false;
    //                 }
    //             }

    //         }

    //         else if (fiber_content_selected_for_number == 3) 
    //         {

    //             if ( (document.getElementById("fiber_total_polyester_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_total_cotton_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_total_thired_tol_value1").value != "") ||
    //                 (document.getElementById("fiber_total_fourth_tol_value1").value != "") )
    //             {
    //                 var total_fiber_content = 0;
    //                 var total_polyester_value = parseInt(document.getElementById("fiber_total_polyester_tol_value1").value);
    //                 var total_cotton_value = parseInt(document.getElementById("fiber_total_cotton_tol_value1").value);
    //                 var total_thired_value = parseInt(document.getElementById("fiber_total_thired_tol_value1").value);
    //                 var total_fourth_value = parseInt(document.getElementById("fiber_total_fourth_tol_value1").value);

    //                 var total_polyester = isNaN(total_polyester_value) ? 0 : total_polyester_value;
    //                 var total_cotton = isNaN(total_cotton_value) ? 0 : total_cotton_value;
    //                 var total_thired = isNaN(total_thired_value) ? 0 : total_thired_value;
    //                 var total_fourth = isNaN(total_fourth_value) ? 0 : total_fourth_value;

    //                 total_fiber_content = total_polyester + total_cotton + total_thired + total_fourth;

    //                 if (total_fiber_content != 100)
    //                 {
    //                     info_alert("Make sure Fiber Total value result exactly 100");
    //                     return false;
    //                 }
    //             }


    //             if ( (document.getElementById("fiber_warp_polyester_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_warp_cotton_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_warp_thired_tol_value1").value != "") ||
    //                 (document.getElementById("fiber_warp_fourth_tol_value1").value != "") )
    //             {
    //                 var total_warp_fiber_content = 0;
    //                 var total_warp_polyester_value = parseInt(document.getElementById("fiber_warp_polyester_tol_value1").value);
    //                 var total_warp_cotton_value = parseInt(document.getElementById("fiber_warp_cotton_tol_value1").value);
    //                 var total_warp_thired_value = parseInt(document.getElementById("fiber_warp_thired_tol_value1").value);
    //                 var total_warp_fourth_value = parseInt(document.getElementById("fiber_warp_fourth_tol_value1").value);

    //                 var total_warp_polyester = isNaN(total_warp_polyester_value) ? 0 : total_warp_polyester_value;
    //                 var total_warp_cotton = isNaN(total_warp_cotton_value) ? 0 : total_warp_cotton_value;
    //                 var total_warp_thired = isNaN(total_warp_thired_value) ? 0 : total_warp_thired_value;
    //                 var total_warp_fourth = isNaN(total_warp_fourth_value) ? 0 : total_warp_fourth_value;

    //                 total_warp_fiber_content = total_warp_polyester + total_warp_cotton + total_warp_thired + total_warp_fourth;

    //                 if (total_warp_fiber_content != 100)
    //                 {
    //                     info_alert("Make sure Fiber Wrap all value result exactly 100");
    //                     return false;
    //                 }
    //             }


    //             if ( (document.getElementById("fiber_weft_polyester_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_weft_cotton_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_weft_thired_tol_value1").value != "") ||
    //                 (document.getElementById("fiber_weft_fourth_tol_value1").value != "") )
    //             {
    //                 var total_weft_fiber_content = 0;

    //                 var total_weft_polyester_value = parseInt(document.getElementById("fiber_weft_polyester_tol_value1").value);
    //                 var total_weft_cotton_value = parseInt(document.getElementById("fiber_weft_cotton_tol_value1").value);
    //                 var total_weft_thired_value = parseInt(document.getElementById("fiber_weft_thired_tol_value1").value);
    //                 var total_weft_fourth_value = parseInt(document.getElementById("fiber_weft_fourth_tol_value1").value);

    //                 var total_weft_polyester = isNaN(total_weft_polyester_value) ? 0 : total_weft_polyester_value;
    //                 var total_weft_cotton = isNaN(total_weft_cotton_value) ? 0 : total_weft_cotton_value;
    //                 var total_weft_thired = isNaN(total_weft_thired_value) ? 0 : total_weft_thired_value;
    //                 var total_weft_fourth = isNaN(total_weft_fourth_value) ? 0 : total_weft_fourth_value;

    //                 total_weft_fiber_content = total_weft_polyester + total_weft_cotton + total_weft_thired + total_weft_fourth;

    //                 if (total_weft_fiber_content != 100)
    //                 {
    //                     info_alert("Make sure Fiber Weft all value result exactly 100");
    //                     return false;
    //                 }
    //             }

    //         }

    //         else
    //         {
    //             info_alert("Something Wrong");
    //             return false;
    //         }
    //     }

    //     else
    //     {
    //         var fiber_content_select = document.getElementById("fiber_content_select").value;

    //         if ( (fiber_content_select == null) || (fiber_content_select == "") ) 
    //         {
    //             if (fiber_content_selected_for_number == 1) 
    //             {
    //                 var total_fiber_content = 0;
    //                 var total_polyester_value = parseInt(document.getElementById("fiber_total_polyester_tol_value1").value);
    //                 var total_cotton_value = parseInt(document.getElementById("fiber_total_cotton_tol_value1").value);
    //                 var total_thired_value = parseInt(document.getElementById("fiber_total_thired_tol_value1").value);
    //                 var total_fourth_value = parseInt(document.getElementById("fiber_total_fourth_tol_value1").value);

    //                 var total_polyester = isNaN(total_polyester_value) ? 0 : total_polyester_value;
    //                 var total_cotton = isNaN(total_cotton_value) ? 0 : total_cotton_value;
    //                 var total_thired = isNaN(total_thired_value) ? 0 : total_thired_value;
    //                 var total_fourth = isNaN(total_fourth_value) ? 0 : total_fourth_value;

    //                 total_fiber_content = total_polyester + total_cotton + total_thired + total_fourth;

    //                 if (total_fiber_content != 100)
    //                 {
    //                     info_alert("Make sure Fiber Total value result exactly 100");
    //                     return false;
    //                 }
                        
    //             }


    //             else if (fiber_content_selected_for_number == 2) 
    //             {
                    
    //                 var total_warp_fiber_content = 0;
    //                 var total_warp_polyester_value = parseInt(document.getElementById("fiber_warp_polyester_tol_value1").value);
    //                 var total_warp_cotton_value = parseInt(document.getElementById("fiber_warp_cotton_tol_value1").value);
    //                 var total_warp_thired_value = parseInt(document.getElementById("fiber_warp_thired_tol_value1").value);
    //                 var total_warp_fourth_value = parseInt(document.getElementById("fiber_warp_fourth_tol_value1").value);

    //                 var total_warp_polyester = isNaN(total_warp_polyester_value) ? 0 : total_warp_polyester_value;
    //                 var total_warp_cotton = isNaN(total_warp_cotton_value) ? 0 : total_warp_cotton_value;
    //                 var total_warp_thired = isNaN(total_warp_thired_value) ? 0 : total_warp_thired_value;
    //                 var total_warp_fourth = isNaN(total_warp_fourth_value) ? 0 : total_warp_fourth_value;

    //                 total_warp_fiber_content = total_warp_polyester + total_warp_cotton + total_warp_thired + total_warp_fourth;

    //                 if (total_warp_fiber_content != 100)
    //                 {
    //                     info_alert("Make sure Fiber Wrap all value result exactly 100");
    //                     return false;
    //                 }


    //                 var total_weft_fiber_content = 0;

    //                 var total_weft_polyester_value = parseInt(document.getElementById("fiber_weft_polyester_tol_value1").value);
    //                 var total_weft_cotton_value = parseInt(document.getElementById("fiber_weft_cotton_tol_value1").value);
    //                 var total_weft_thired_value = parseInt(document.getElementById("fiber_weft_thired_tol_value1").value);
    //                 var total_weft_fourth_value = parseInt(document.getElementById("fiber_weft_fourth_tol_value1").value);

    //                 var total_weft_polyester = isNaN(total_weft_polyester_value) ? 0 : total_weft_polyester_value;
    //                 var total_weft_cotton = isNaN(total_weft_cotton_value) ? 0 : total_weft_cotton_value;
    //                 var total_weft_thired = isNaN(total_weft_thired_value) ? 0 : total_weft_thired_value;
    //                 var total_weft_fourth = isNaN(total_weft_fourth_value) ? 0 : total_weft_fourth_value;

    //                 total_weft_fiber_content = total_weft_polyester + total_weft_cotton + total_weft_thired + total_weft_fourth;

    //                 if (total_weft_fiber_content != 100)
    //                 {
    //                     info_alert("Make sure Fiber Weft all value result exactly 100");
    //                     return false;
    //                 }

    //             }

    //             else if (fiber_content_selected_for_number == 3) 
    //             {
    //                 var total_fiber_content = 0;
    //                 var total_polyester_value = parseInt(document.getElementById("fiber_total_polyester_tol_value1").value);
    //                 var total_cotton_value = parseInt(document.getElementById("fiber_total_cotton_tol_value1").value);
    //                 var total_thired_value = parseInt(document.getElementById("fiber_total_thired_tol_value1").value);
    //                 var total_fourth_value = parseInt(document.getElementById("fiber_total_fourth_tol_value1").value);

    //                 var total_polyester = isNaN(total_polyester_value) ? 0 : total_polyester_value;
    //                 var total_cotton = isNaN(total_cotton_value) ? 0 : total_cotton_value;
    //                 var total_thired = isNaN(total_thired_value) ? 0 : total_thired_value;
    //                 var total_fourth = isNaN(total_fourth_value) ? 0 : total_fourth_value;

    //                 total_fiber_content = total_polyester + total_cotton + total_thired + total_fourth;

    //                 if (total_fiber_content != 100)
    //                 {
    //                     info_alert("Make sure Fiber Total value result exactly 100");
    //                     return false;
    //                 }

    //                 var total_warp_fiber_content = 0;
    //                 var total_warp_polyester_value = parseInt(document.getElementById("fiber_warp_polyester_tol_value1").value);
    //                 var total_warp_cotton_value = parseInt(document.getElementById("fiber_warp_cotton_tol_value1").value);
    //                 var total_warp_thired_value = parseInt(document.getElementById("fiber_warp_thired_tol_value1").value);
    //                 var total_warp_fourth_value = parseInt(document.getElementById("fiber_warp_fourth_tol_value1").value);

    //                 var total_warp_polyester = isNaN(total_warp_polyester_value) ? 0 : total_warp_polyester_value;
    //                 var total_warp_cotton = isNaN(total_warp_cotton_value) ? 0 : total_warp_cotton_value;
    //                 var total_warp_thired = isNaN(total_warp_thired_value) ? 0 : total_warp_thired_value;
    //                 var total_warp_fourth = isNaN(total_warp_fourth_value) ? 0 : total_warp_fourth_value;

    //                 total_warp_fiber_content = total_warp_polyester + total_warp_cotton + total_warp_thired + total_warp_fourth;

    //                 if (total_warp_fiber_content != 100)
    //                 {
    //                     info_alert("Make sure Fiber Wrap all value result exactly 100");
    //                     return false;
    //                 }


                    
    //                 var total_weft_fiber_content = 0;

    //                 var total_weft_polyester_value = parseInt(document.getElementById("fiber_weft_polyester_tol_value1").value);
    //                 var total_weft_cotton_value = parseInt(document.getElementById("fiber_weft_cotton_tol_value1").value);
    //                 var total_weft_thired_value = parseInt(document.getElementById("fiber_weft_thired_tol_value1").value);
    //                 var total_weft_fourth_value = parseInt(document.getElementById("fiber_weft_fourth_tol_value1").value);

    //                 var total_weft_polyester = isNaN(total_weft_polyester_value) ? 0 : total_weft_polyester_value;
    //                 var total_weft_cotton = isNaN(total_weft_cotton_value) ? 0 : total_weft_cotton_value;
    //                 var total_weft_thired = isNaN(total_weft_thired_value) ? 0 : total_weft_thired_value;
    //                 var total_weft_fourth = isNaN(total_weft_fourth_value) ? 0 : total_weft_fourth_value;

    //                 total_weft_fiber_content = total_weft_polyester + total_weft_cotton + total_weft_thired + total_weft_fourth;

    //                 if (total_weft_fiber_content != 100)
    //                 {
    //                     info_alert("Make sure Fiber Weft all value result exactly 100");
    //                     return false;
    //                 }

    //             }

    //             else
    //             {
    //                 info_alert("Something Wrong");
    //                 return false;
    //             }
    //         }

    //         else
    //         {
    //             if (fiber_content_selected_for_number == 1) 
    //             {   
    //                 if ( (document.getElementById("fiber_total_polyester_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_total_cotton_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_total_thired_tol_value1").value != "") ||
    //                 (document.getElementById("fiber_total_fourth_tol_value1").value != "") )
    //                 {
    //                     var total_fiber_content = 0;
    //                     var total_polyester_value = parseInt(document.getElementById("fiber_total_polyester_tol_value1").value);
    //                     var total_cotton_value = parseInt(document.getElementById("fiber_total_cotton_tol_value1").value);
    //                     var total_thired_value = parseInt(document.getElementById("fiber_total_thired_tol_value1").value);
    //                     var total_fourth_value = parseInt(document.getElementById("fiber_total_fourth_tol_value1").value);

    //                     var total_polyester = isNaN(total_polyester_value) ? 0 : total_polyester_value;
    //                     var total_cotton = isNaN(total_cotton_value) ? 0 : total_cotton_value;
    //                     var total_thired = isNaN(total_thired_value) ? 0 : total_thired_value;
    //                     var total_fourth = isNaN(total_fourth_value) ? 0 : total_fourth_value;

    //                     total_fiber_content = total_polyester + total_cotton + total_thired + total_fourth;

    //                     if (total_fiber_content != 100)
    //                     {
    //                         info_alert("Make sure Fiber Total value result exactly 100");
    //                         return false;
    //                     }
    //                 }
                        
    //             }


    //             else if (fiber_content_selected_for_number == 2) 
    //             {
    //                 if ( (document.getElementById("fiber_warp_polyester_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_warp_cotton_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_warp_thired_tol_value1").value != "") ||
    //                 (document.getElementById("fiber_warp_fourth_tol_value1").value != "") )
    //                 {
    //                     var total_warp_fiber_content = 0;
    //                     var total_warp_polyester_value = parseInt(document.getElementById("fiber_warp_polyester_tol_value1").value);
    //                     var total_warp_cotton_value = parseInt(document.getElementById("fiber_warp_cotton_tol_value1").value);
    //                     var total_warp_thired_value = parseInt(document.getElementById("fiber_warp_thired_tol_value1").value);
    //                     var total_warp_fourth_value = parseInt(document.getElementById("fiber_warp_fourth_tol_value1").value);

    //                     var total_warp_polyester = isNaN(total_warp_polyester_value) ? 0 : total_warp_polyester_value;
    //                     var total_warp_cotton = isNaN(total_warp_cotton_value) ? 0 : total_warp_cotton_value;
    //                     var total_warp_thired = isNaN(total_warp_thired_value) ? 0 : total_warp_thired_value;
    //                     var total_warp_fourth = isNaN(total_warp_fourth_value) ? 0 : total_warp_fourth_value;

    //                     total_warp_fiber_content = total_warp_polyester + total_warp_cotton + total_warp_thired + total_warp_fourth;

    //                     if (total_warp_fiber_content != 100)
    //                     {
    //                         info_alert("Make sure Fiber Wrap all value result exactly 100");
    //                         return false;
    //                     }
    //                 }


    //                 if ( (document.getElementById("fiber_weft_polyester_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_weft_cotton_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_weft_thired_tol_value1").value != "") ||
    //                 (document.getElementById("fiber_weft_fourth_tol_value1").value != "") )
    //                 {
    //                     var total_weft_fiber_content = 0;

    //                     var total_weft_polyester_value = parseInt(document.getElementById("fiber_weft_polyester_tol_value1").value);
    //                     var total_weft_cotton_value = parseInt(document.getElementById("fiber_weft_cotton_tol_value1").value);
    //                     var total_weft_thired_value = parseInt(document.getElementById("fiber_weft_thired_tol_value1").value);
    //                     var total_weft_fourth_value = parseInt(document.getElementById("fiber_weft_fourth_tol_value1").value);

    //                     var total_weft_polyester = isNaN(total_weft_polyester_value) ? 0 : total_weft_polyester_value;
    //                     var total_weft_cotton = isNaN(total_weft_cotton_value) ? 0 : total_weft_cotton_value;
    //                     var total_weft_thired = isNaN(total_weft_thired_value) ? 0 : total_weft_thired_value;
    //                     var total_weft_fourth = isNaN(total_weft_fourth_value) ? 0 : total_weft_fourth_value;

    //                     total_weft_fiber_content = total_weft_polyester + total_weft_cotton + total_weft_thired + total_weft_fourth;

    //                     if (total_weft_fiber_content != 100)
    //                     {
    //                         info_alert("Make sure Fiber Weft all value result exactly 100");
    //                         return false;
    //                     }
    //                 }

    //             }

    //             else if (fiber_content_selected_for_number == 3) 
    //             {
    //                 if ( (document.getElementById("fiber_total_polyester_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_total_cotton_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_total_thired_tol_value1").value != "") ||
    //                 (document.getElementById("fiber_total_fourth_tol_value1").value != "") )
    //                 {
    //                     var total_fiber_content = 0;
    //                     var total_polyester_value = parseInt(document.getElementById("fiber_total_polyester_tol_value1").value);
    //                     var total_cotton_value = parseInt(document.getElementById("fiber_total_cotton_tol_value1").value);
    //                     var total_thired_value = parseInt(document.getElementById("fiber_total_thired_tol_value1").value);
    //                     var total_fourth_value = parseInt(document.getElementById("fiber_total_fourth_tol_value1").value);

    //                     var total_polyester = isNaN(total_polyester_value) ? 0 : total_polyester_value;
    //                     var total_cotton = isNaN(total_cotton_value) ? 0 : total_cotton_value;
    //                     var total_thired = isNaN(total_thired_value) ? 0 : total_thired_value;
    //                     var total_fourth = isNaN(total_fourth_value) ? 0 : total_fourth_value;

    //                     total_fiber_content = total_polyester + total_cotton + total_thired + total_fourth;

    //                     if (total_fiber_content != 100)
    //                     {
    //                         info_alert("Make sure Fiber Total value result exactly 100");
    //                         return false;
    //                     }
    //                 }


    //                 if ( (document.getElementById("fiber_warp_polyester_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_warp_cotton_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_warp_thired_tol_value1").value != "") ||
    //                 (document.getElementById("fiber_warp_fourth_tol_value1").value != "") )
    //                 {
    //                     var total_warp_fiber_content = 0;
    //                     var total_warp_polyester_value = parseInt(document.getElementById("fiber_warp_polyester_tol_value1").value);
    //                     var total_warp_cotton_value = parseInt(document.getElementById("fiber_warp_cotton_tol_value1").value);
    //                     var total_warp_thired_value = parseInt(document.getElementById("fiber_warp_thired_tol_value1").value);
    //                     var total_warp_fourth_value = parseInt(document.getElementById("fiber_warp_fourth_tol_value1").value);

    //                     var total_warp_polyester = isNaN(total_warp_polyester_value) ? 0 : total_warp_polyester_value;
    //                     var total_warp_cotton = isNaN(total_warp_cotton_value) ? 0 : total_warp_cotton_value;
    //                     var total_warp_thired = isNaN(total_warp_thired_value) ? 0 : total_warp_thired_value;
    //                     var total_warp_fourth = isNaN(total_warp_fourth_value) ? 0 : total_warp_fourth_value;

    //                     total_warp_fiber_content = total_warp_polyester + total_warp_cotton + total_warp_thired + total_warp_fourth;

    //                     if (total_warp_fiber_content != 100)
    //                     {
    //                         info_alert("Make sure Fiber Wrap all value result exactly 100");
    //                         return false;
    //                     }
    //                 }


    //                 if ( (document.getElementById("fiber_weft_polyester_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_weft_cotton_tol_value1").value != "") || 
    //                 (document.getElementById("fiber_weft_thired_tol_value1").value != "") ||
    //                 (document.getElementById("fiber_weft_fourth_tol_value1").value != "") )
    //                 {
    //                     var total_weft_fiber_content = 0;

    //                     var total_weft_polyester_value = parseInt(document.getElementById("fiber_weft_polyester_tol_value1").value);
    //                     var total_weft_cotton_value = parseInt(document.getElementById("fiber_weft_cotton_tol_value1").value);
    //                     var total_weft_thired_value = parseInt(document.getElementById("fiber_weft_thired_tol_value1").value);
    //                     var total_weft_fourth_value = parseInt(document.getElementById("fiber_weft_fourth_tol_value1").value);

    //                     var total_weft_polyester = isNaN(total_weft_polyester_value) ? 0 : total_weft_polyester_value;
    //                     var total_weft_cotton = isNaN(total_weft_cotton_value) ? 0 : total_weft_cotton_value;
    //                     var total_weft_thired = isNaN(total_weft_thired_value) ? 0 : total_weft_thired_value;
    //                     var total_weft_fourth = isNaN(total_weft_fourth_value) ? 0 : total_weft_fourth_value;

    //                     total_weft_fiber_content = total_weft_polyester + total_weft_cotton + total_weft_thired + total_weft_fourth;

    //                     if (total_weft_fiber_content != 100)
    //                     {
    //                         info_alert("Make sure Fiber Weft all value result exactly 100");
    //                         return false;
    //                     }

    //                 }
    //             }

    //             else
    //             {
    //                 info_alert("Something Wrong");
    //                 return false;
    //             }
    //         }
    //     }
    // }

    // else
    // {
    //     info_alert("Please Select Fiber Content");
    //     return false;
    // }
}